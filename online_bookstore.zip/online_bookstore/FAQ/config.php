<?php
    $conn = mysqli_connect('localhost','root','','logininfor') or die('connection failed');
?>