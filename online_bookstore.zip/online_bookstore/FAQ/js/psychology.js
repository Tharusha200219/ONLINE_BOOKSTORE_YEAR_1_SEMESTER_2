alert("Welcome to the psychology Category.");

/*const books = [
    {
        title: "Book 01",
        author: "Author 01",
        description: "Description of book 01",
        coverImage: "../imgs/book1.jpeg"
    },
    {
        title: "Book 02",
        author: "Author 02",
        description: "Description of book 02",
        coverImage: "../imgs/book1.jpeg"
    },
    {
        title: "Book 03",
        author: "Author 03",
        description: "Description of book 03",
        coverImage: "../imgs/book1.jpeg"
    },
];

function displayBooks(){

    const bookListElement = document.getElementById("bookList")

    books.forEach(book => {
        const bookItem = document.createElement("div");
        bookItem.classList.add("book");

        const bookTitle = document.createElement("h6");
        bookTitle.textContent = "By " +  book.title;

        const bookAuthor = document.createElement("p");
        bookAuthor.textContent = book.author;

        const bookDescription = document.createElement("p");
        bookDescription.textContent = book.description;

        const bookCover = document.createElement("img");
        bookCover.src = book.coverImage;
        bookCover.alt = book.title;

        bookItem.appendChild(bookCover);
        bookItem.appendChild(bookTitle);
        bookItem.appendChild(bookAuthor);
        bookItem.appendChild(bookDescription);

        bookListElement.appendChild(bookItem);

    });
}*/